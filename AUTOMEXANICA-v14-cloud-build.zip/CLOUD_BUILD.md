# AUTOMEXANICA — облачная сборка APK

Этот проект подготовлен для сборки через GitHub Actions без Android Studio и без компьютера.

## Как собрать со смартфона

1. Создайте репозиторий на GitHub.
2. Загрузите в него содержимое этого проекта.
3. Откройте вкладку **Actions**.
4. Выберите **Build AUTOMEXANICA APK**.
5. Нажмите **Run workflow**.
6. После завершения откройте выполненный workflow.
7. Внизу страницы скачайте artifact **AUTOMEXANICA-debug**.
8. Внутри будет `app-debug.apk`.

Workflow использует JDK 17 и Gradle Wrapper проекта.
