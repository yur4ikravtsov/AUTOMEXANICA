package com.example.simplecrm.data

data class PaymentMethodTotal(
    val method: String,
    val total: Double
)

data class PaymentReportTotals(
    val total: Double,
    val cash: Double,
    val card: Double,
    val bankTransfer: Double,
    val other: Double
)
