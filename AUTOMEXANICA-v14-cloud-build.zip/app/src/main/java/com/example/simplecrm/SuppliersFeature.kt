package com.example.simplecrm

import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import com.example.simplecrm.data.*

@Composable
fun SuppliersFeature(
    dao: CrmDao,
    onClose: () -> Unit
) {
    val suppliers by dao.supplierBalances().collectAsState(initial = emptyList())
    var screen by remember { mutableStateOf("list") }
    var selectedId by remember { mutableLongStateOf(0L) }
    var editingSupplier by remember { mutableStateOf<Supplier?>(null) }
    var editingPurchase by remember { mutableStateOf<SupplierPurchase?>(null) }
    var paymentDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val supplier by if (selectedId != 0L) dao.supplier(selectedId).collectAsState(initial = null)
        else remember { mutableStateOf(null) }
    val purchases by if (selectedId != 0L) dao.supplierPurchases(selectedId).collectAsState(initial = emptyList())
        else remember { mutableStateOf(emptyList()) }

    val purchasePaid = remember(purchases) {
        mutableStateMapOf<Long, Double>().also { map ->
            // Values are filled by per-purchase collectors in the detail screen.
            purchases.forEach { map[it.id] = 0.0 }
        }
    }

    when (screen) {
        "list" -> SupplierListScreen(
            suppliers = suppliers,
            onBack = onClose,
            onAdd = { editingSupplier = null; screen = "editSupplier" },
            onOpen = { selectedId = it; screen = "detail" }
        )
        "editSupplier" -> SupplierEditScreen(
            initial = editingSupplier,
            onBack = { screen = "list" },
            onSave = {
                if (it.id == 0L) {
                    scope.launch { dao.insertSupplier(it); screen = "list" }
                } else {
                    scope.launch { dao.updateSupplier(it); screen = "list" }
                }
            }
        )
        "detail" -> {
            if (supplier != null) {
                // Collect paid totals for each purchase.
                val paidMap = purchases.associate { p ->
                    val paid by dao.supplierPurchasePaidAmount(p.id).collectAsState(initial = 0.0)
                    p.id to paid
                }
                SupplierDetailScreen(
                    supplier = supplier!!,
                    purchases = purchases,
                    purchasePaid = paidMap,
                    onBack = { screen = "list" },
                    onEdit = { editingSupplier = supplier; screen = "editSupplier" },
                    onDelete = {
                        scope.launch { dao.deleteSupplier(supplier!!); screen = "list" }
                    },
                    onAddPurchase = { editingPurchase = null; screen = "editPurchase" },
                    onOpenPurchase = { selectedId = it; screen = "purchaseDetail" }
                )
            }
        }
        "editPurchase" -> SupplierPurchaseEditScreen(
            supplierId = selectedId,
            initial = editingPurchase,
            onBack = { screen = "detail" },
            onSave = {
                if (it.id == 0L) {
                    scope.launch { dao.insertSupplierPurchase(it); screen = "detail" }
                } else {
                    scope.launch { dao.updateSupplierPurchase(it); screen = "detail" }
                }
            }
        )
        "purchaseDetail" -> {
            val purchase by dao.supplierPurchase(selectedId).collectAsState(initial = null)
            if (purchase != null) {
                val paid by dao.supplierPurchasePaidAmount(selectedId).collectAsState(initial = 0.0)
                val payments by dao.supplierPayments(selectedId).collectAsState(initial = emptyList())
                SupplierPurchaseDetailScreen(
                    purchase = purchase!!,
                    paid = paid,
                    payments = payments,
                    onBack = { screen = "detail" },
                    onAddPayment = { paymentDialog = true },
                    onDeletePurchase = {
                        scope.launch { dao.deleteSupplierPurchase(purchase!!); screen = "detail" }
                    },
                    onDeletePayment = { id ->
                        scope.launch { dao.deleteSupplierPayment(id) }
                    }
                )
                if (paymentDialog) {
                    SupplierPaymentDialog(
                        maxAmount = (purchase!!.amount - paid).coerceAtLeast(0.0),
                        onDismiss = { paymentDialog = false },
                        onSave = { amount, method, comment ->
                            scope.launch { dao.insertSupplierPayment(
                                    SupplierPayment(
                                        supplierId = purchase!!.supplierId,
                                        purchaseId = purchase!!.id,
                                        amount = amount,
                                        method = method,
                                        comment = comment
                                    )
                                ); paymentDialog = false }
                        }
                    )
                }
            }
        }
    }
}
