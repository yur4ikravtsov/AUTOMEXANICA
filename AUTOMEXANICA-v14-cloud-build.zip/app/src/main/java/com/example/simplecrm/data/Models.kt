package com.example.simplecrm.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val email: String = "",
    val status: String = "Новый",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long? = null,
    val title: String,
    val dueAt: Long? = null,
    val completed: Boolean = false
)


@Entity(
    tableName = "machines",
    foreignKeys = [
        ForeignKey(
            entity = Client::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("clientId")]
)
data class Machine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val brand: String,
    val model: String,
    val year: Int? = null,
    val vin: String = "",
    val plateNumber: String = "",
    val serialNumber: String = "",
    val usageValue: String = "",
    val comment: String = ""
)


@Entity(
    tableName = "orders",
    foreignKeys = [
        ForeignKey(entity = Client::class, parentColumns = ["id"], childColumns = ["clientId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Machine::class, parentColumns = ["id"], childColumns = ["machineId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("clientId"), Index("machineId")]
)
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val machineId: Long? = null,
    val status: String = "Новый",
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "order_items",
    foreignKeys = [
        ForeignKey(entity = Order::class, parentColumns = ["id"], childColumns = ["orderId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("orderId")]
)
data class OrderItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val partNumber: String,
    val name: String,
    val quantity: Double = 1.0,
    val price: Double = 0.0
)



@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(entity = Order::class, parentColumns = ["id"], childColumns = ["orderId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("orderId")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val amount: Double,
    val paidAt: Long = System.currentTimeMillis(),
    val comment: String = ""
)

data class PaymentWithOrder(
    val id: Long,
    val orderId: Long,
    val amount: Double,
    val paidAt: Long,
    val comment: String,
    val orderTotal: Double,
    val orderStatus: String
)

data class UnpaidOrder(
    val id: Long,
    val machineId: Long?,
    val status: String,
    val createdAt: Long,
    val total: Double,
    val paid: Double,
    val remaining: Double
)

data class OrderWithDetails(
    val id: Long,
    val clientId: Long,
    val machineId: Long?,
    val clientName: String,
    val machineBrand: String?,
    val machineModel: String?,
    val status: String,
    val comment: String,
    val createdAt: Long
)


@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val contactPerson: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val registrationNumber: String = "",
    val note: String = "",
    val status: String = "Активен",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "supplier_purchases",
    foreignKeys = [
        ForeignKey(
            entity = Supplier::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("supplierId")]
)
data class SupplierPurchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long,
    val documentNumber: String = "",
    val purchaseDate: Long = System.currentTimeMillis(),
    val amount: Double,
    val comment: String = ""
)

@Entity(
    tableName = "supplier_payments",
    foreignKeys = [
        ForeignKey(
            entity = Supplier::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SupplierPurchase::class,
            parentColumns = ["id"],
            childColumns = ["purchaseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("supplierId"), Index("purchaseId")]
)
data class SupplierPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val supplierId: Long,
    val purchaseId: Long,
    val paidAt: Long = System.currentTimeMillis(),
    val amount: Double,
    val method: String = "Банковский перевод",
    val comment: String = ""
)

data class SupplierBalanceRow(
    val id: Long,
    val name: String,
    val contactPerson: String,
    val phone: String,
    val email: String,
    val address: String,
    val registrationNumber: String,
    val note: String,
    val status: String,
    val createdAt: Long,
    val totalPurchases: Double,
    val totalPaid: Double
)
