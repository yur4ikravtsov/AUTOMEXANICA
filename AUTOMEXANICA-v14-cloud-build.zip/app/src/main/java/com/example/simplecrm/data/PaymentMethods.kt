package com.example.simplecrm.data

object PaymentMethods {
    val all = listOf(
        "Наличные",
        "Карта",
        "Банковский перевод",
        "Другое"
    )
}
