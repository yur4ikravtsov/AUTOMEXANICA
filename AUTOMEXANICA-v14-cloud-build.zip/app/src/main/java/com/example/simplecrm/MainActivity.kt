package com.example.simplecrm

import android.os.Bundle
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.simplecrm.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

object NotificationScheduler {
    private const val EXTRA_TASK_ID = "task_id"
    private const val EXTRA_TITLE = "task_title"
    private const val CHANNEL_ID = "crm_tasks"
    private const val CHANNEL_NAME = "Задачи CRM"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(
                android.app.NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    android.app.NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Напоминания о задачах AUTOMEXANICA"
                }
            )
        }
    }

    fun schedule(context: Context, task: Task) {
        val due = task.dueAt ?: return
        if (due <= System.currentTimeMillis() || task.completed) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) return

        val intent = Intent(context, TaskNotificationReceiver::class.java).apply {
            putExtra(EXTRA_TASK_ID, task.id)
            putExtra(EXTRA_TITLE, task.title)
        }
        val pending = PendingIntent.getBroadcast(
            context,
            task.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pending)
    }

    fun cancel(context: Context, taskId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TaskNotificationReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            taskId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pending)
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= 31) {
            context.startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = android.net.Uri.parse("package:${context.packageName}")
                }
            )
        }
    }

    fun notificationPermissionGranted(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
}

class TaskNotificationReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        createNotification(context, intent.getLongExtra(NotificationScheduler.EXTRA_TASK_ID, 0L),
            intent.getStringExtra(NotificationScheduler.EXTRA_TITLE) ?: "Задача")
    }

    private fun createNotification(context: Context, taskId: Long, title: String) {
        NotificationScheduler.createChannel(context)
        if (!NotificationScheduler.notificationPermissionGranted(context)) return

        val openIntent = Intent(context, MainActivity::class.java)
        val contentPending = PendingIntent.getActivity(
            context, taskId.toInt(), openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = androidx.core.app.NotificationCompat.Builder(context, "crm_tasks")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Напоминание о задаче")
            .setContentText(title)
            .setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(title))
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentPending)
            .build()

        androidx.core.app.NotificationManagerCompat.from(context).notify(taskId.toInt(), notification)
    }
}

class CrmViewModel(private val dao: CrmDao, private val appContext: Context) : ViewModel() {
    var search by mutableStateOf("")
    val clients = dao.clients(search)
    val tasks = dao.tasks()

    private val dayStart = MutableStateFlow(startOfToday())
    val todayTasks = dayStart.flatMapLatest { start ->
        dao.todayTasks(start, start + 24L * 60L * 60L * 1000L)
    }
    val overdueTasks = dayStart.flatMapLatest { start ->
        dao.overdueTasks(start)
    }

    fun addClient(name: String, phone: String, email: String, status: String) =
        viewModelScope.launch { dao.insertClient(Client(name = name, phone = phone, email = email, status = status)) }

    fun updateClient(client: Client) = viewModelScope.launch { dao.updateClient(client) }
    fun deleteClient(client: Client) = viewModelScope.launch { dao.deleteClient(client) }
    fun addNote(clientId: Long, text: String) = viewModelScope.launch { dao.insertNote(Note(clientId = clientId, text = text)) }
    fun addTask(title: String, clientId: Long?, dueAt: Long?) = viewModelScope.launch {
        val id = dao.insertTask(Task(title = title, clientId = clientId, dueAt = dueAt))
        val task = Task(id = id, title = title, clientId = clientId, dueAt = dueAt)
        NotificationScheduler.schedule(appContext, task)
    }
    fun toggleTask(task: Task) = viewModelScope.launch {
        val updated = task.copy(completed = !task.completed)
        dao.updateTask(updated)
        if (updated.completed) NotificationScheduler.cancel(appContext, updated.id)
        else NotificationScheduler.schedule(appContext, updated)
    }
    fun updateTask(task: Task) = viewModelScope.launch {
        dao.updateTask(task)
        NotificationScheduler.cancel(appContext, task.id)
        NotificationScheduler.schedule(appContext, task)
    }
    fun addMachine(machine: Machine) = viewModelScope.launch { dao.insertMachine(machine) }
    fun updateMachine(machine: Machine) = viewModelScope.launch { dao.updateMachine(machine) }
    fun deleteMachine(machine: Machine) = viewModelScope.launch { dao.deleteMachine(machine) }
    fun addOrder(order: Order, items: List<OrderItem>) = viewModelScope.launch {
        val orderId = dao.insertOrder(order)
        items.forEach { dao.insertOrderItem(it.copy(orderId = orderId)) }
    }
    fun updateOrder(order: Order) = viewModelScope.launch { dao.updateOrder(order) }
    fun deleteOrder(order: Order) = viewModelScope.launch { dao.deleteOrder(order) }
    fun addPayment(payment: Payment) = viewModelScope.launch { dao.insertPayment(payment) }
    fun deletePayment(payment: Payment) = viewModelScope.launch { dao.deletePayment(payment) }
    fun daoOrders(): Flow<List<OrderWithDetails>> = dao.ordersWithDetails()
    fun daoClients(): Flow<List<Client>> = dao.allClients()

    fun deleteTask(task: Task) = viewModelScope.launch {
        dao.deleteTask(task)
        NotificationScheduler.cancel(appContext, task.id)
    }
}

fun startOfToday(): Long {
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationScheduler.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(
                android.Manifest.permission.POST_NOTIFICATIONS
            )
        }
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            NotificationScheduler.openExactAlarmSettings(this)
        }

        val dao = CrmDatabase.get(this).dao()
        setContent {
            val vm: CrmViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    CrmViewModel(dao, applicationContext) as T
            })
            MaterialTheme {
                CRMApp(vm)
            }
        }
    }
}

@Composable
fun CRMApp(vm: CrmViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var selectedClient by remember { mutableStateOf<Client?>(null) }

    if (selectedClient != null) {
        ClientScreen(
            client = selectedClient!!,
            dao = CrmDatabase.get(androidx.compose.ui.platform.LocalContext.current).dao(),
            onAddTask = { title, dueAt -> vm.addTask(title, selectedClient!!.id, dueAt) },
            onAddMachine = { vm.addMachine(it) },
            onUpdateMachine = { vm.updateMachine(it) },
            onDeleteMachine = { vm.deleteMachine(it) },
            onAddPayment = { vm.addPayment(it) },
            onDeletePayment = { vm.deletePayment(it) },
            onBack = { selectedClient = null },
            onStatus = { vm.updateClient(selectedClient!!.copy(status = it)); selectedClient = selectedClient!!.copy(status = it) },
            onEdit = { updated ->
                vm.updateClient(updated)
                selectedClient = updated
            },
            onDelete = {
                vm.deleteClient(selectedClient!!)
                selectedClient = null
            }
        )
        return
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Simple CRM") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Главная") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("Клиенты") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.CheckCircle, null) }, label = { Text("Задачи") })
                NavigationBarItem(tab == 3, { tab = 3 }, icon = { Icon(Icons.Default.ShoppingCart, null) }, label = { Text("Заказы") })
            }
        },
        floatingActionButton = {
            if (tab == 1) {
                FloatingActionButton(onClick = { showAddClient(vm) }) {
                    Icon(Icons.Default.Add, "Добавить")
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> DashboardScreen(vm)
                1 -> ClientsScreen(vm) { selectedClient = it }
                2 -> TasksScreen(vm)
                else -> OrdersScreen(vm)
            }
        }
    }
}

private fun showAddClient(vm: CrmViewModel) {
    // FAB action is handled by AddClientDialog in ClientsScreen via its own state.
}

@Composable
fun DashboardScreen(vm: CrmViewModel) {
    val clients by vm.clients.collectAsState(initial = emptyList())
    val today by vm.todayTasks.collectAsState(initial = emptyList())
    val overdue by vm.overdueTasks.collectAsState(initial = emptyList())

    val newCount = clients.count { it.status == "Новый" }
    val workCount = clients.count { it.status == "В работе" }
    val customerCount = clients.count { it.status == "Клиент" }
    val refusedCount = clients.count { it.status == "Отказ" }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Обзор", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Всего", clients.size, Modifier.weight(1f))
                StatCard("Новые", newCount, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("В работе", workCount, Modifier.weight(1f))
                StatCard("Клиенты", customerCount, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Отказы", refusedCount, Modifier.weight(1f))
                StatCard("Просрочено", overdue.size, Modifier.weight(1f))
            }
        }
        item {
            Text("Задачи на сегодня", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (today.isEmpty()) {
            item { Text("На сегодня задач нет.") }
        } else {
            items(today, key = { it.id }) { task ->
                TaskSummaryCard(task, vm)
            }
        }
        item {
            Text("Просроченные задачи", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (overdue.isEmpty()) {
            item { Text("Просроченных задач нет.") }
        } else {
            items(overdue, key = { it.id }) { task ->
                TaskSummaryCard(task, vm, overdue = true)
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: Int, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(value.toString(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun TaskSummaryCard(task: Task, vm: CrmViewModel, overdue: Boolean = false) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(task.completed, { vm.toggleTask(task) })
            Column(Modifier.weight(1f)) {
                Text(task.title, fontWeight = FontWeight.Medium)
                task.dueAt?.let {
                    Text(
                        (if (overdue) "Просрочено: " else "") + formatDateTime(it),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

fun formatDateTime(time: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(time))

@Composable
fun ClientsScreen(vm: CrmViewModel, onClient: (Client) -> Unit) {
    var add by remember { mutableStateOf(false) }
    val clients by vm.clients.collectAsState(initial = emptyList())

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = vm.search,
            onValueChange = { vm.search = it },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Поиск по имени, телефону, email") },
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PersonAdd, null)
            Spacer(Modifier.width(8.dp))
            Text("Добавить клиента")
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(clients, key = { it.id }) { client ->
                ClientCard(client) { onClient(client) }
            }
        }
    }
    if (add) {
        AddClientDialog(onDismiss = { add = false }) { n, p, e, s ->
            vm.addClient(n, p, e, s); add = false
        }
    }
}

@Composable
fun ClientCard(client: Client, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(16.dp)) {
            Text(client.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (client.phone.isNotBlank()) Text(client.phone)
            if (client.email.isNotBlank()) Text(client.email)
            Spacer(Modifier.height(6.dp))
            AssistChip(onClick = {}, label = { Text(client.status) })
        }
    }
}

@Composable
fun AddClientDialog(onDismiss: () -> Unit, onSave: (String,String,String,String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Новый") }
    val statuses = listOf("Новый", "В работе", "Клиент", "Отказ")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый клиент") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Имя / компания") })
                OutlinedTextField(phone, { phone = it }, label = { Text("Телефон") })
                OutlinedTextField(email, { email = it }, label = { Text("Email") })
                Text("Статус")
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    statuses.forEach { s ->
                        FilterChip(selected = status == s, onClick = { status = s }, label = { Text(s) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onSave(name, phone, email, status) }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}


@Composable
fun MachineCard(
    machine: Machine,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(
                "${machine.brand} ${machine.model}".trim(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            machine.year?.let { Text("Год: $it") }
            if (machine.vin.isNotBlank()) Text("VIN: ${machine.vin}")
            if (machine.plateNumber.isNotBlank()) Text("Госномер: ${machine.plateNumber}")
            if (machine.serialNumber.isNotBlank()) Text("Серийный номер: ${machine.serialNumber}")
            if (machine.usageValue.isNotBlank()) Text("Пробег / моточасы: ${machine.usageValue}")
            if (machine.comment.isNotBlank()) Text("Комментарий: ${machine.comment}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Изменить")
                }
                OutlinedButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Удалить")
                }
            }
        }
    }
}

@Composable
fun MachineDialog(
    clientId: Long,
    machine: Machine? = null,
    onDismiss: () -> Unit,
    onSave: (Machine) -> Unit
) {
    var brand by remember { mutableStateOf(machine?.brand ?: "") }
    var model by remember { mutableStateOf(machine?.model ?: "") }
    var year by remember { mutableStateOf(machine?.year?.toString() ?: "") }
    var vin by remember { mutableStateOf(machine?.vin ?: "") }
    var plate by remember { mutableStateOf(machine?.plateNumber ?: "") }
    var serial by remember { mutableStateOf(machine?.serialNumber ?: "") }
    var usage by remember { mutableStateOf(machine?.usageValue ?: "") }
    var comment by remember { mutableStateOf(machine?.comment ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (machine == null) "Добавить технику" else "Редактировать технику") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(brand, { brand = it }, label = { Text("Марка") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("Модель") }, singleLine = true)
                OutlinedTextField(
                    year, { year = it.filter(Char::isDigit).take(4) },
                    label = { Text("Год") }, singleLine = true
                )
                OutlinedTextField(vin, { vin = it.uppercase() }, label = { Text("VIN") }, singleLine = true)
                OutlinedTextField(plate, { plate = it }, label = { Text("Госномер") }, singleLine = true)
                OutlinedTextField(serial, { serial = it }, label = { Text("Серийный номер") }, singleLine = true)
                OutlinedTextField(usage, { usage = it }, label = { Text("Пробег / моточасы") }, singleLine = true)
                OutlinedTextField(
                    comment, { comment = it },
                    label = { Text("Комментарий") },
                    minLines = 2
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = brand.isNotBlank() && model.isNotBlank(),
                onClick = {
                    onSave(
                        Machine(
                            id = machine?.id ?: 0,
                            clientId = clientId,
                            brand = brand.trim(),
                            model = model.trim(),
                            year = year.toIntOrNull(),
                            vin = vin.trim(),
                            plateNumber = plate.trim(),
                            serialNumber = serial.trim(),
                            usageValue = usage.trim(),
                            comment = comment.trim()
                        )
                    )
                }
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun EditClientDialog(
    client: Client,
    onDismiss: () -> Unit,
    onSave: (Client) -> Unit
) {
    var name by remember { mutableStateOf(client.name) }
    var phone by remember { mutableStateOf(client.phone) }
    var email by remember { mutableStateOf(client.email) }
    var status by remember { mutableStateOf(client.status) }
    val statuses = listOf("Новый", "В работе", "Клиент", "Отказ")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать клиента") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Имя / компания") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Телефон") }, singleLine = true)
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true)
                Text("Статус")
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    statuses.forEach { value ->
                        FilterChip(selected = status == value, onClick = { status = value }, label = { Text(value) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave(client.copy(name = name.trim(), phone = phone.trim(), email = email.trim(), status = status))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun ClientScreen(
    client: Client,
    dao: CrmDao,
    onAddTask: (String, Long?) -> Unit,
    onAddMachine: (Machine) -> Unit,
    onUpdateMachine: (Machine) -> Unit,
    onDeleteMachine: (Machine) -> Unit,
    onAddPayment: (Payment) -> Unit,
    onDeletePayment: (Payment) -> Unit,
    onBack: () -> Unit,
    onStatus: (String) -> Unit,
    onEdit: (Client) -> Unit,
    onDelete: () -> Unit
) {
    val notes by dao.notes(client.id).collectAsState(initial = emptyList())
    val machines by dao.machines(client.id).collectAsState(initial = emptyList())
    val clientOrders by dao.ordersWithDetailsForClient(client.id).collectAsState(initial = emptyList())
    val clientPayments by dao.paymentsForClient(client.id).collectAsState(initial = emptyList())
    val unpaidOrders by dao.unpaidOrdersForClient(client.id).collectAsState(initial = emptyList())
    val clientDebt by dao.clientDebt(client.id).collectAsState(initial = 0.0)
    var note by remember { mutableStateOf("") }
    var task by remember { mutableStateOf("") }
    var taskDate by remember { mutableStateOf<Long?>(null) }
    var editing by remember { mutableStateOf(false) }
    var taskDatePicker by remember { mutableStateOf(false) }
    var taskTimePicker by remember { mutableStateOf(false) }
    var machineDialog by remember { mutableStateOf(false) }
    var editingMachine by remember { mutableStateOf<Machine?>(null) }
    var deletingMachine by remember { mutableStateOf<Machine?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var paymentDialog by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(client.name) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
        )
    }) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("Статус", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Новый","В работе","Клиент","Отказ").forEach {
                        FilterChip(selected = client.status == it, onClick = { onStatus(it) }, label = { Text(it) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (client.phone.isNotBlank()) Text("Телефон: ${client.phone}")
                if (client.email.isNotBlank()) Text("Email: ${client.email}")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { editing = true }) {
                        Icon(Icons.Default.Edit, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Редактировать")
                    }
                    OutlinedButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.Delete, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Удалить")
                    }
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Техника клиента", fontWeight = FontWeight.Bold)
                    Button(onClick = { machineDialog = true }) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Добавить")
                    }
                }
            }
            if (machines.isEmpty()) {
                item { Text("Техника пока не добавлена.") }
            } else {
                items(machines, key = { it.id }) { machine ->
                    MachineCard(
                        machine = machine,
                        onEdit = { editingMachine = machine },
                        onDelete = { deletingMachine = machine }
                    )
                }
            }

            item {
                Text("Финансы", fontWeight = FontWeight.Bold)
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Общая задолженность", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(formatMoney(clientDebt), style = MaterialTheme.typography.headlineSmall)
                        Text(if (unpaidOrders.isEmpty()) "Неоплаченных заказов нет." else "Неоплаченных заказов: ${unpaidOrders.size}")
                        Button(enabled = unpaidOrders.isNotEmpty(), onClick = { paymentDialog = true }) {
                            Text("Добавить оплату")
                        }
                    }
                }
            }
            item { Text("Заказы с неоплаченным остатком", fontWeight = FontWeight.Bold) }
            if (unpaidOrders.isEmpty()) {
                item { Text("Все заказы оплачены.") }
            } else {
                items(unpaidOrders, key = { it.id }) { unpaid ->
                    UnpaidOrderCard(unpaid, machines)
                }
            }

            item { Text("История оплат", fontWeight = FontWeight.Bold) }
            if (clientPayments.isEmpty()) {
                item { Text("Оплат пока нет.") }
            } else {
                items(clientPayments, key = { it.id }) { payment ->
                    PaymentHistoryCard(payment, onDelete = { onDeletePayment(Payment(payment.id, payment.orderId, payment.amount, payment.paidAt, payment.comment)) })
                }
            }

            item {
                Text("История заказов", fontWeight = FontWeight.Bold)
            }
            if (clientOrders.isEmpty()) {
                item { Text("Заказов пока нет.") }
            } else {
                items(clientOrders, key = { it.id }) { order ->
                    ClientOrderHistoryCard(order, dao)
                }
            }

            item {
                Text("Добавить заметку", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(note, { note = it }, modifier = Modifier.weight(1f), placeholder = { Text("Текст заметки") })
                    IconButton(enabled = note.isNotBlank(), onClick = {
                        kotlinx.coroutines.MainScope().launch { dao.insertNote(Note(clientId = client.id, text = note)); note = "" }
                    }) { Icon(Icons.Default.Send, null) }
                }
            }
            item { Text("Заметки", fontWeight = FontWeight.Bold) }
            items(notes) {
                Card(Modifier.fillMaxWidth()) { Text(it.text, Modifier.padding(12.dp)) }
            }
            item {
                Text("Новая задача", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = task,
                    onValueChange = { task = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Например: позвонить") }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { taskDatePicker = true }) {
                        Icon(Icons.Default.CalendarMonth, null)
                        Spacer(Modifier.width(6.dp))
                        Text(taskDate?.let { formatDate(it) } ?: "Дата")
                    }
                    OutlinedButton(enabled = taskDate != null, onClick = { taskTimePicker = true }) {
                        Icon(Icons.Default.Schedule, null)
                        Spacer(Modifier.width(6.dp))
                        Text(taskDate?.let { formatTime(it) } ?: "Время")
                    }
                    IconButton(enabled = task.isNotBlank(), onClick = {
                        onAddTask(task, taskDate)
                        task = ""
                        taskDate = null
                    }) { Icon(Icons.Default.AddTask, null) }
                }
            }
        }
    }
}



    if (paymentDialog) {
        AddPaymentDialog(
            unpaidOrders = unpaidOrders,
            onDismiss = { paymentDialog = false },
            onSave = {
                onAddPayment(it)
                paymentDialog = false
            }
        )
    }

    if (machineDialog) {
        MachineDialog(
            clientId = client.id,
            onDismiss = { machineDialog = false },
            onSave = {
                onAddMachine(it)
                machineDialog = false
            }
        )
    }

    editingMachine?.let { machine ->
        MachineDialog(
            clientId = client.id,
            machine = machine,
            onDismiss = { editingMachine = null },
            onSave = {
                onUpdateMachine(it)
                editingMachine = null
            }
        )
    }

    deletingMachine?.let { machine ->
        AlertDialog(
            onDismissRequest = { deletingMachine = null },
            title = { Text("Удалить технику?") },
            text = { Text("«${machine.brand} ${machine.model}» будет удалена из карточки клиента.") },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteMachine(machine)
                    deletingMachine = null
                }) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { deletingMachine = null }) { Text("Отмена") }
            }
        )
    }

    if (taskDatePicker) {
        DatePickerDialog(
            onDismissRequest = { taskDatePicker = false },
            onDateSelected = { millis ->
                taskDate = mergeDate(taskDate, millis)
                taskDatePicker = false
                taskTimePicker = true
            }
        )
    }

    if (taskTimePicker && taskDate != null) {
        TimePickerDialog(
            initialMillis = taskDate!!,
            onDismissRequest = { taskTimePicker = false },
            onTimeSelected = { hour, minute ->
                taskDate = mergeTime(taskDate!!, hour, minute)
                taskTimePicker = false
            }
        )
    }

    if (editing) {
        EditClientDialog(
            client = client,
            onDismiss = { editing = false },
            onSave = {
                onEdit(it)
                editing = false
            }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить клиента?") },
            text = { Text("Клиент «${client.name}» будет удалён. Это действие нельзя отменить.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete()
                }) { Text("Удалить") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Отмена") }
            }
        )
    }
}


@Composable
fun UnpaidOrderCard(order: UnpaidOrder, machines: List<Machine>) {
    val machine = machines.firstOrNull { it.id == order.machineId }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Заказ №${order.id}", fontWeight = FontWeight.Bold)
            Text("Статус: ${order.status}")
            if (machine != null) Text("Техника: ${machine.brand} ${machine.model}")
            Text("Сумма: ${formatMoney(order.total)}")
            Text("Оплачено: ${formatMoney(order.paid)}")
            Text("Остаток: ${formatMoney(order.remaining)}", fontWeight = FontWeight.Bold)
            Text(formatDateTime(order.createdAt), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun PaymentHistoryCard(payment: PaymentWithOrder, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Заказ №${payment.orderId}", fontWeight = FontWeight.Bold)
                Text("+${formatMoney(payment.amount)}", fontWeight = FontWeight.Bold)
            }
            Text(formatDateTime(payment.paidAt), style = MaterialTheme.typography.bodySmall)
            Text("Заказ: ${payment.orderStatus} • сумма ${formatMoney(payment.orderTotal)}")
            if (payment.comment.isNotBlank()) Text("Комментарий: ${payment.comment}")
            TextButton(onClick = onDelete) { Text("Удалить оплату") }
        }
    }
}

@Composable
fun AddPaymentDialog(
    unpaidOrders: List<UnpaidOrder>,
    onDismiss: () -> Unit,
    onSave: (Payment) -> Unit
) {
    var selectedOrder by remember(unpaidOrders) { mutableStateOf(unpaidOrders.firstOrNull()) }
    var amount by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить оплату") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Заказ")
                LazyColumn(Modifier.heightIn(max = 160.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(unpaidOrders, key = { it.id }) { order ->
                        FilterChip(
                            selected = selectedOrder?.id == order.id,
                            onClick = {
                                selectedOrder = order
                                amount = ""
                            },
                            label = { Text("№${order.id} • остаток ${formatMoney(order.remaining)}") }
                        )
                    }
                }
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it.replace(',', '.').filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("Сумма оплаты") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Комментарий") },
                    minLines = 2
                )
            }
        },
        confirmButton = {
            val value = amount.toDoubleOrNull()
            TextButton(
                enabled = selectedOrder != null && value != null && value > 0 && value <= (selectedOrder?.remaining ?: 0.0) + 0.000001,
                onClick = {
                    onSave(
                        Payment(
                            orderId = selectedOrder!!.id,
                            amount = value!!,
                            comment = comment.trim()
                        )
                    )
                }
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun ClientOrderHistoryCard(order: OrderWithDetails, dao: CrmDao) {
    val items by dao.orderItems(order.id).collectAsState(initial = emptyList())
    val total = items.sumOf { it.quantity * it.price }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Заказ №${order.id}", fontWeight = FontWeight.Bold)
            Text(formatDateTime(order.createdAt), style = MaterialTheme.typography.bodySmall)
            if (!order.machineBrand.isNullOrBlank()) Text("Техника: ${order.machineBrand} ${order.machineModel ?: ""}".trim())
            AssistChip(onClick = {}, label = { Text(order.status) })
            items.forEach { item ->
                Text("• ${item.name.ifBlank { item.partNumber }} — ${item.quantity} шт. × ${formatMoney(item.price)}")
            }
            Text("Итого: ${formatMoney(total)}", fontWeight = FontWeight.Bold)
        }
    }
}

fun formatMoney(value: Double): String = String.format(Locale.getDefault(), "%.2f", value)

@Composable
fun OrdersScreen(vm: CrmViewModel) {
    val orders by vm.daoOrders().collectAsState(initial = emptyList())
    val clients by vm.daoClients().collectAsState(initial = emptyList())
    var add by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<OrderWithDetails?>(null) }
    val dao = CrmDatabase.get(androidx.compose.ui.platform.LocalContext.current).dao()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { add = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.ShoppingCart, null)
            Spacer(Modifier.width(8.dp))
            Text("Новый заказ")
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(orders, key = { it.id }) { order ->
                val itemList by dao.orderItems(order.id).collectAsState(initial = emptyList())
                val total = itemList.sumOf { it.quantity * it.price }
                Card(Modifier.fillMaxWidth().clickable { selected = order }) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Заказ №${order.id}", fontWeight = FontWeight.Bold)
                            AssistChip(onClick = {}, label = { Text(order.status) })
                        }
                        Text(order.clientName)
                        if (!order.machineBrand.isNullOrBlank()) Text("Техника: ${order.machineBrand} ${order.machineModel ?: ""}".trim())
                        Text("${itemList.size} поз. • ${formatMoney(total)}")
                        Text(formatDateTime(order.createdAt), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (orders.isEmpty()) item { Text("Заказов пока нет.") }
        }
    }

    if (add) {
        OrderDialog(
            clients = clients,
            dao = dao,
            onDismiss = { add = false },
            onSave = { order, items ->
                vm.addOrder(order, items)
                add = false
            }
        )
    }

    selected?.let { order ->
        OrderDetailsDialog(
            order = order,
            dao = dao,
            onDismiss = { selected = null },
            onStatus = { status -> vm.updateOrder(Order(id = order.id, clientId = order.clientId, machineId = order.machineId, status = status, comment = order.comment, createdAt = order.createdAt)); selected = null },
            onDelete = { vm.deleteOrder(Order(id = order.id, clientId = order.clientId, machineId = order.machineId, status = order.status, comment = order.comment, createdAt = order.createdAt)); selected = null }
        )
    }
}

@Composable
fun OrderDialog(
    clients: List<Client>,
    dao: CrmDao,
    onDismiss: () -> Unit,
    onSave: (Order, List<OrderItem>) -> Unit
) {
    var selectedClient by remember { mutableStateOf<Client?>(clients.firstOrNull()) }
    var selectedMachine by remember { mutableStateOf<Machine?>(null) }
    var status by remember { mutableStateOf("Новый") }
    var comment by remember { mutableStateOf("") }
    var showClients by remember { mutableStateOf(false) }
    var showMachines by remember { mutableStateOf(false) }
    val machines = if (selectedClient != null) {
        dao.machines(selectedClient!!.id).collectAsState(initial = emptyList()).value
    } else {
        emptyList()
    }
    var items by remember { mutableStateOf(listOf<DraftOrderItem>()) }
    val statuses = listOf("Новый", "В работе", "Ожидает поставки", "Готов", "Выдан", "Возврат", "Отменён")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый заказ") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 520.dp)) {
                item {
                    OutlinedButton(onClick = { showClients = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedClient?.name ?: "Выбрать клиента")
                    }
                    if (selectedClient != null) {
                        OutlinedButton(onClick = { showMachines = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selectedMachine?.let { "Техника: ${it.brand} ${it.model}" } ?: "Выбрать технику")
                        }
                    }
                }
                item {
                    Text("Статус")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        statuses.forEach { s ->
                            FilterChip(selected = status == s, onClick = { status = s }, label = { Text(s) })
                        }
                    }
                }
                item { Text("Позиции", fontWeight = FontWeight.Bold) }
                items.forEachIndexed { index, item ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            OutlinedTextField(item.partNumber, { value -> items = items.toMutableList().also { it[index] = item.copy(partNumber = value) } }, label = { Text("Артикул") }, singleLine = true)
                            OutlinedTextField(item.name, { value -> items = items.toMutableList().also { it[index] = item.copy(name = value) } }, label = { Text("Название") }, singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(item.quantity, { value -> items = items.toMutableList().also { it[index] = item.copy(quantity = value) } }, label = { Text("Кол-во") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(item.price, { value -> items = items.toMutableList().also { it[index] = item.copy(price = value) } }, label = { Text("Цена") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                            TextButton(onClick = { items = items.filterIndexed { i, _ -> i != index } }) { Text("Удалить позицию") }
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { items = items + DraftOrderItem() }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Добавить позицию")
                    }
                }
                item { OutlinedTextField(comment, { comment = it }, label = { Text("Комментарий") }, minLines = 2, modifier = Modifier.fillMaxWidth()) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selectedClient != null && items.any { it.name.isNotBlank() || it.partNumber.isNotBlank() },
                onClick = {
                    val client = selectedClient!!
                    val order = Order(clientId = client.id, machineId = selectedMachine?.id, status = status, comment = comment.trim())
                    val orderItems = items.filter { it.name.isNotBlank() || it.partNumber.isNotBlank() }.map { Draft -> OrderItem(orderId = 0, partNumber = Draft.partNumber.trim(), name = Draft.name.trim(), quantity = Draft.quantity.toDoubleOrNull() ?: 1.0, price = Draft.price.toDoubleOrNull() ?: 0.0) }
                    onSave(order, orderItems)
                }
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )

    if (showClients) {
        AlertDialog(onDismissRequest = { showClients = false }, title = { Text("Выберите клиента") }, text = {
            LazyColumn { clients.forEach { client -> item { TextButton(onClick = { selectedClient = client; selectedMachine = null; showClients = false }, modifier = Modifier.fillMaxWidth()) { Text(client.name) } } } }
        }, confirmButton = {})
    }
    if (showMachines) {
        AlertDialog(onDismissRequest = { showMachines = false }, title = { Text("Выберите технику") }, text = {
            LazyColumn {
                item { TextButton(onClick = { selectedMachine = null; showMachines = false }, modifier = Modifier.fillMaxWidth()) { Text("Без привязки к технике") } }
                machines.forEach { machine -> item { TextButton(onClick = { selectedMachine = machine; showMachines = false }, modifier = Modifier.fillMaxWidth()) { Text("${machine.brand} ${machine.model}") } } }
            }
        }, confirmButton = {})
    }
}

data class DraftOrderItem(val partNumber: String = "", val name: String = "", val quantity: String = "1", val price: String = "0")

@Composable
fun OrderDetailsDialog(order: OrderWithDetails, dao: CrmDao, onDismiss: () -> Unit, onStatus: (String) -> Unit, onDelete: () -> Unit) {
    val items by dao.orderItems(order.id).collectAsState(initial = emptyList())
    val total = items.sumOf { it.quantity * it.price }
    val statuses = listOf("Новый", "В работе", "Ожидает поставки", "Готов", "Выдан", "Возврат", "Отменён")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Заказ №${order.id}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(order.clientName, fontWeight = FontWeight.Bold)
                if (!order.machineBrand.isNullOrBlank()) Text("Техника: ${order.machineBrand} ${order.machineModel ?: ""}".trim())
                Text("Позиции", fontWeight = FontWeight.Bold)
                items.forEach { Text("• ${it.partNumber.ifBlank { it.name }} — ${it.quantity} × ${formatMoney(it.price)}") }
                Text("Итого: ${formatMoney(total)}", fontWeight = FontWeight.Bold)
                Text("Изменить статус")
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { statuses.forEach { s -> FilterChip(selected = order.status == s, onClick = { onStatus(s) }, label = { Text(s) }) } }
                if (order.comment.isNotBlank()) Text("Комментарий: ${order.comment}")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
        dismissButton = { TextButton(onClick = onDelete) { Text("Удалить") } }
    )
}

@Composable
fun TasksScreen(vm: CrmViewModel) {
    val tasks by vm.tasks.collectAsState(initial = emptyList())
    var editingTask by remember { mutableStateOf<Task?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(tasks, key = { it.id }) { task ->
            Card(Modifier.fillMaxWidth().clickable { editingTask = task }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(task.completed, { vm.toggleTask(task) })
                    Column(Modifier.weight(1f)) {
                        Text(task.title, fontWeight = FontWeight.Medium)
                        task.dueAt?.let {
                            Text(
                                "Срок: ${formatDateTime(it)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        } ?: Text("Срок не задан", style = MaterialTheme.typography.bodySmall)
                        if (task.completed) Text("Выполнено", style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Default.Edit, contentDescription = "Редактировать")
                }
            }
        }
        if (tasks.isEmpty()) item { Text("Задач пока нет.") }
    }

    editingTask?.let { task ->
        EditTaskDialog(
            task = task,
            onDismiss = { editingTask = null },
            onSave = {
                vm.updateTask(it)
                editingTask = null
            },
            onDelete = {
                vm.deleteTask(task)
                editingTask = null
            }
        )
    }
}

@Composable
fun EditTaskDialog(
    task: Task,
    onDismiss: () -> Unit,
    onSave: (Task) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember { mutableStateOf(task.title) }
    var dueAt by remember { mutableStateOf(task.dueAt) }
    var datePicker by remember { mutableStateOf(false) }
    var timePicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Редактировать задачу") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Задача") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { datePicker = true }) {
                        Icon(Icons.Default.CalendarMonth, null)
                        Spacer(Modifier.width(6.dp))
                        Text(dueAt?.let { formatDate(it) } ?: "Дата")
                    }
                    OutlinedButton(enabled = dueAt != null, onClick = { timePicker = true }) {
                        Icon(Icons.Default.Schedule, null)
                        Spacer(Modifier.width(6.dp))
                        Text(dueAt?.let { formatTime(it) } ?: "Время")
                    }
                }
                if (dueAt != null) {
                    Text("Срок: ${formatDateTime(dueAt!!)}")
                    TextButton(onClick = { dueAt = null }) { Text("Убрать срок") }
                }
                TextButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Удалить задачу")
                }
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                onSave(task.copy(title = title.trim(), dueAt = dueAt))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )

    if (datePicker) {
        DatePickerDialog(
            onDismissRequest = { datePicker = false },
            onDateSelected = {
                dueAt = mergeDate(dueAt, it)
                datePicker = false
                timePicker = true
            }
        )
    }

    if (timePicker && dueAt != null) {
        TimePickerDialog(
            initialMillis = dueAt!!,
            onDismissRequest = { timePicker = false },
            onTimeSelected = { hour, minute ->
                dueAt = mergeTime(dueAt!!, hour, minute)
                timePicker = false
            }
        )
    }
}

@Composable
fun DatePickerDialog(onDismissRequest: () -> Unit, onDateSelected: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
    DatePickerDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let(onDateSelected)
            }) { Text("Выбрать") }
        },
        dismissButton = { TextButton(onClick = onDismissRequest) { Text("Отмена") } }
    ) {
        DatePicker(state = state)
    }
}

@Composable
fun TimePickerDialog(
    initialMillis: Long,
    onDismissRequest: () -> Unit,
    onTimeSelected: (Int, Int) -> Unit
) {
    val cal = Calendar.getInstance().apply { timeInMillis = initialMillis }
    val state = rememberTimePickerState(
        initialHour = cal.get(Calendar.HOUR_OF_DAY),
        initialMinute = cal.get(Calendar.MINUTE),
        is24Hour = true
    )
    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text("Выберите время") },
        text = { TimePicker(state = state) },
        confirmButton = {
            TextButton(onClick = { onTimeSelected(state.hour, state.minute) }) { Text("Выбрать") }
        },
        dismissButton = { TextButton(onClick = onDismissRequest) { Text("Отмена") } }
    )
}

fun mergeDate(oldMillis: Long?, selectedMillis: Long): Long {
    val selected = Calendar.getInstance().apply { timeInMillis = selectedMillis }
    val result = Calendar.getInstance().apply {
        timeInMillis = oldMillis ?: System.currentTimeMillis()
        set(Calendar.YEAR, selected.get(Calendar.YEAR))
        set(Calendar.MONTH, selected.get(Calendar.MONTH))
        set(Calendar.DAY_OF_MONTH, selected.get(Calendar.DAY_OF_MONTH))
    }
    return result.timeInMillis
}

fun mergeTime(oldMillis: Long, hour: Int, minute: Int): Long {
    val result = Calendar.getInstance().apply {
        timeInMillis = oldMillis
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return result.timeInMillis
}

fun formatDate(time: Long): String =
    SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(time))

fun formatTime(time: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))

fun formatDateTime(time: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(time))

