package com.example.simplecrm

import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.example.simplecrm.data.*
import java.text.SimpleDateFormat
import java.util.*

private val supplierDateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

private fun money(value: Double): String = String.format(Locale.getDefault(), "%.2f", value)

@Composable
fun SupplierListScreen(
    suppliers: List<SupplierBalanceRow>,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onOpen: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = suppliers.filter {
        query.isBlank() ||
        it.name.contains(query, true) ||
        it.phone.contains(query, true) ||
        it.contactPerson.contains(query, true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Поставщики") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                },
                actions = {
                    IconButton(onClick = onAdd) { Icon(Icons.Default.Add, null) }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                placeholder = { Text("Поиск поставщика") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true
            )
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp)) {
                    Text("Поставщиков пока нет")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { s ->
                        Card(
                            Modifier.fillMaxWidth().clickable { onOpen(s.id) }
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(s.name, style = MaterialTheme.typography.titleMedium)
                                if (s.contactPerson.isNotBlank()) Text("Контакт: ${s.contactPerson}")
                                if (s.phone.isNotBlank()) Text("Телефон: ${s.phone}")
                                Spacer(Modifier.height(8.dp))
                                Text("Закупки: ${money(s.totalPurchases)}")
                                Text("Оплачено: ${money(s.totalPaid)}")
                                Text(
                                    "Долг поставщику: ${money((s.totalPurchases - s.totalPaid).coerceAtLeast(0.0))}",
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SupplierEditScreen(
    initial: Supplier?,
    onBack: () -> Unit,
    onSave: (Supplier) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var contact by remember { mutableStateOf(initial?.contactPerson ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var email by remember { mutableStateOf(initial?.email ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var reg by remember { mutableStateOf(initial?.registrationNumber ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: "Активен") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initial == null) "Новый поставщик" else "Редактирование") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Название компании *") })
            OutlinedTextField(contact, { contact = it }, Modifier.fillMaxWidth(), label = { Text("Контактное лицо") })
            OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text("Телефон") })
            OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") })
            OutlinedTextField(address, { address = it }, Modifier.fillMaxWidth(), label = { Text("Адрес") })
            OutlinedTextField(reg, { reg = it }, Modifier.fillMaxWidth(), label = { Text("ИНН / регистрационные данные") })
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Заметки") })
            Text("Статус")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Активен", "Неактивен").forEach {
                    FilterChip(selected = status == it, onClick = { status = it }, label = { Text(it) })
                }
            }
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            Supplier(
                                id = initial?.id ?: 0,
                                name = name.trim(),
                                contactPerson = contact.trim(),
                                phone = phone.trim(),
                                email = email.trim(),
                                address = address.trim(),
                                registrationNumber = reg.trim(),
                                note = note.trim(),
                                status = status,
                                createdAt = initial?.createdAt ?: System.currentTimeMillis()
                            )
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Сохранить") }
        }
    }
}

@Composable
fun SupplierDetailScreen(
    supplier: Supplier,
    purchases: List<SupplierPurchase>,
    purchasePaid: Map<Long, Double>,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAddPurchase: () -> Unit,
    onOpenPurchase: (Long) -> Unit
) {
    val total = purchases.sumOf { it.amount }
    val paid = purchases.sumOf { purchasePaid[it.id] ?: 0.0 }
    val debt = (total - paid).coerceAtLeast(0.0)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(supplier.name) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, null) }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null) }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddPurchase) { Icon(Icons.Default.Add, null) }
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Реквизиты", style = MaterialTheme.typography.titleMedium)
                        if (supplier.contactPerson.isNotBlank()) Text("Контакт: ${supplier.contactPerson}")
                        if (supplier.phone.isNotBlank()) Text("Телефон: ${supplier.phone}")
                        if (supplier.email.isNotBlank()) Text("Email: ${supplier.email}")
                        if (supplier.address.isNotBlank()) Text("Адрес: ${supplier.address}")
                        if (supplier.registrationNumber.isNotBlank()) Text("ИНН/рег.: ${supplier.registrationNumber}")
                        Text("Статус: ${supplier.status}")
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Взаиморасчёты", style = MaterialTheme.typography.titleMedium)
                        Text("Всего закупок: ${money(total)}")
                        Text("Оплачено: ${money(paid)}")
                        Text("Долг поставщику: ${money(debt)}")
                    }
                }
            }
            item { Text("Закупки", style = MaterialTheme.typography.titleLarge) }
            items(purchases, key = { it.id }) { p ->
                val pPaid = purchasePaid[p.id] ?: 0.0
                val rest = (p.amount - pPaid).coerceAtLeast(0.0)
                Card(Modifier.fillMaxWidth().clickable { onOpenPurchase(p.id) }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            if (p.documentNumber.isBlank()) "Закупка #${p.id}"
                            else "Документ: ${p.documentNumber}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text("Дата: ${supplierDateFormat.format(Date(p.purchaseDate))}")
                        Text("Сумма: ${money(p.amount)}")
                        Text("Оплачено: ${money(pPaid)}")
                        Text("Остаток: ${money(rest)}")
                        Text(
                            when {
                                pPaid <= 0.0 -> "Не оплачено"
                                rest > 0.0 -> "Частично оплачено"
                                else -> "Оплачено"
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SupplierPurchaseEditScreen(
    supplierId: Long,
    initial: SupplierPurchase?,
    onBack: () -> Unit,
    onSave: (SupplierPurchase) -> Unit
) {
    val context = LocalContext.current
    var document by remember { mutableStateOf(initial?.documentNumber ?: "") }
    var amount by remember { mutableStateOf(initial?.amount?.toString() ?: "") }
    var comment by remember { mutableStateOf(initial?.comment ?: "") }
    var date by remember { mutableLongStateOf(initial?.purchaseDate ?: System.currentTimeMillis()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initial == null) "Новая закупка" else "Редактирование закупки") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(document, { document = it }, Modifier.fillMaxWidth(), label = { Text("Номер документа") })
            OutlinedTextField(
                amount, { amount = it },
                Modifier.fillMaxWidth(),
                label = { Text("Сумма *") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
            OutlinedButton(
                onClick = {
                    val cal = Calendar.getInstance().apply { timeInMillis = date }
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            cal.set(y, m, d, 12, 0, 0)
                            date = cal.timeInMillis
                        },
                        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Дата: ${supplierDateFormat.format(Date(date))}") }
            OutlinedTextField(comment, { comment = it }, Modifier.fillMaxWidth(), label = { Text("Комментарий") })
            Button(
                onClick = {
                    val value = amount.replace(',', '.').toDoubleOrNull()
                    if (value != null && value > 0) {
                        onSave(
                            SupplierPurchase(
                                id = initial?.id ?: 0,
                                supplierId = supplierId,
                                documentNumber = document.trim(),
                                purchaseDate = date,
                                amount = value,
                                comment = comment.trim()
                            )
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Сохранить") }
        }
    }
}

@Composable
fun SupplierPurchaseDetailScreen(
    purchase: SupplierPurchase,
    paid: Double,
    payments: List<SupplierPayment>,
    onBack: () -> Unit,
    onAddPayment: () -> Unit,
    onDeletePurchase: () -> Unit,
    onDeletePayment: (Long) -> Unit
) {
    val rest = (purchase.amount - paid).coerceAtLeast(0.0)
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Закупка #${purchase.id}") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = onDeletePurchase) { Icon(Icons.Default.Delete, null) }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddPayment) { Icon(Icons.Default.Add, null) }
        }
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(if (purchase.documentNumber.isBlank()) "Закупка" else "Документ: ${purchase.documentNumber}", style = MaterialTheme.typography.titleMedium)
                        Text("Дата: ${supplierDateFormat.format(Date(purchase.purchaseDate))}")
                        Text("Сумма: ${money(purchase.amount)}")
                        Text("Оплачено: ${money(paid)}")
                        Text("Остаток: ${money(rest)}")
                        Text(
                            when {
                                paid <= 0.0 -> "Не оплачено"
                                rest > 0.0 -> "Частично оплачено"
                                else -> "Оплачено"
                            }
                        )
                        if (purchase.comment.isNotBlank()) Text("Комментарий: ${purchase.comment}")
                    }
                }
            }
            item { Text("Платежи", style = MaterialTheme.typography.titleLarge) }
            if (payments.isEmpty()) {
                item { Text("Платежей пока нет") }
            } else {
                items(payments, key = { it.id }) { payment ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text("${money(payment.amount)} — ${payment.method}")
                                Text(supplierDateFormat.format(Date(payment.paidAt)))
                                if (payment.comment.isNotBlank()) Text(payment.comment)
                            }
                            IconButton(onClick = { onDeletePayment(payment.id) }) {
                                Icon(Icons.Default.Delete, null)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SupplierPaymentDialog(
    maxAmount: Double,
    onDismiss: () -> Unit,
    onSave: (Double, String, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Банковский перевод") }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Оплата поставщику") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Остаток: ${money(maxAmount)}")
                OutlinedTextField(
                    amount, { amount = it },
                    label = { Text("Сумма") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                Text("Способ оплаты")
                PaymentMethods.all.forEach {
                    FilterChip(selected = method == it, onClick = { method = it }, label = { Text(it) })
                }
                OutlinedTextField(comment, { comment = it }, label = { Text("Комментарий") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val value = amount.replace(',', '.').toDoubleOrNull()
                if (value != null && value > 0 && value <= maxAmount + 0.0001) {
                    onSave(value, method, comment.trim())
                }
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
