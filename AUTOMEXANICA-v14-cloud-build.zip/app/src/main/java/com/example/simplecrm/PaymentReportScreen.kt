package com.example.simplecrm

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.simplecrm.data.CrmDatabase
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class ReportPeriod { TODAY, CURRENT_MONTH, CUSTOM }

private fun dayStart(time: Long): Long {
    val c = Calendar.getInstance().apply { timeInMillis = time }
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}
private fun dayEnd(time: Long): Long {
    val c = Calendar.getInstance().apply { timeInMillis = time }
    c.set(Calendar.HOUR_OF_DAY, 23); c.set(Calendar.MINUTE, 59)
    c.set(Calendar.SECOND, 59); c.set(Calendar.MILLISECOND, 999)
    return c.timeInMillis
}
private fun monthStart(time: Long): Long {
    val c = Calendar.getInstance().apply { timeInMillis = time }
    c.set(Calendar.DAY_OF_MONTH, 1)
    return dayStart(c.timeInMillis)
}
private fun monthEnd(time: Long): Long {
    val c = Calendar.getInstance().apply { timeInMillis = time }
    c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH))
    return dayEnd(c.timeInMillis)
}

@Composable
fun PaymentReportScreen(
    database: CrmDatabase,
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val now = System.currentTimeMillis()
    var period by remember { mutableStateOf(ReportPeriod.TODAY) }
    var fromDate by remember { mutableLongStateOf(dayStart(now)) }
    var toDate by remember { mutableLongStateOf(dayEnd(now)) }

    fun pickDate(initial: Long, onPicked: (Long) -> Unit) {
        val c = Calendar.getInstance().apply { timeInMillis = initial }
        DatePickerDialog(
            context,
            { _, year, month, day ->
                val picked = Calendar.getInstance().apply {
                    set(year, month, day, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                onPicked(picked.timeInMillis)
            },
            c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    fun setPreset(p: ReportPeriod) {
        period = p
        when (p) {
            ReportPeriod.TODAY -> {
                val t = System.currentTimeMillis()
                fromDate = dayStart(t); toDate = dayEnd(t)
            }
            ReportPeriod.CURRENT_MONTH -> {
                val t = System.currentTimeMillis()
                fromDate = monthStart(t); toDate = monthEnd(t)
            }
            ReportPeriod.CUSTOM -> Unit
        }
    }

    val rows by database.crmDao().paymentMethodReport(fromDate, toDate)
        .collectAsState(initial = emptyList())
    val total by database.crmDao().paymentTotalReport(fromDate, toDate)
        .collectAsState(initial = 0.0)

    val money = NumberFormat.getCurrencyInstance(Locale.getDefault())
    val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Отчёт по способам оплаты", style = MaterialTheme.typography.headlineSmall)
            Text("${dateFormat.format(Date(fromDate))} — ${dateFormat.format(Date(toDate))}")
        }

        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (period == ReportPeriod.TODAY)
                    Button(onClick = { setPreset(ReportPeriod.TODAY) }) { Text("Сегодня") }
                else
                    OutlinedButton(onClick = { setPreset(ReportPeriod.TODAY) }) { Text("Сегодня") }

                if (period == ReportPeriod.CURRENT_MONTH)
                    Button(onClick = { setPreset(ReportPeriod.CURRENT_MONTH) }) { Text("Месяц") }
                else
                    OutlinedButton(onClick = { setPreset(ReportPeriod.CURRENT_MONTH) }) { Text("Месяц") }
            }
        }

        item {
            Text("Произвольный диапазон", style = MaterialTheme.typography.titleMedium)
        }

        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    modifier = Modifier.weight(1f),
                    onClick = {
                        pickDate(fromDate) { selected ->
                            if (selected <= toDate) {
                                fromDate = selected
                                period = ReportPeriod.CUSTOM
                            } else {
                                toDate = dayEnd(selected)
                                fromDate = selected
                                period = ReportPeriod.CUSTOM
                            }
                        }
                    }
                ) {
                    Text("Дата от\n${dateFormat.format(Date(fromDate))}")
                }

                OutlinedButton(
                    modifier = Modifier.weight(1f),
                    onClick = {
                        pickDate(toDate) { selected ->
                            if (selected >= fromDate) {
                                toDate = dayEnd(selected)
                                period = ReportPeriod.CUSTOM
                            } else {
                                fromDate = dayStart(selected)
                                toDate = dayEnd(selected)
                                period = ReportPeriod.CUSTOM
                            }
                        }
                    }
                ) {
                    Text("Дата до\n${dateFormat.format(Date(toDate))}")
                }
            }
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Всего получено", style = MaterialTheme.typography.titleMedium)
                    Text(money.format(total), style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        items(rows) { row ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(row.method)
                    Text(money.format(row.total))
                }
            }
        }
    }
}
