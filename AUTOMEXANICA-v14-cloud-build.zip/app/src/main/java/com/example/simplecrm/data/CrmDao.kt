package com.example.simplecrm.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CrmDao {
    @Query("""
        SELECT * FROM clients
        WHERE name LIKE '%' || :query || '%'
           OR phone LIKE '%' || :query || '%'
           OR email LIKE '%' || :query || '%'
        ORDER BY name COLLATE NOCASE
    """)
    fun clients(query: String): Flow<List<Client>>

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun client(id: Long): Client?

    @Insert
    suspend fun insertClient(client: Client): Long

    @Update
    suspend fun updateClient(client: Client)

    @Delete
    suspend fun deleteClient(client: Client)

    @Query("SELECT * FROM machines WHERE clientId = :clientId ORDER BY brand COLLATE NOCASE, model COLLATE NOCASE")
    fun machines(clientId: Long): Flow<List<Machine>>

    @Insert
    suspend fun insertMachine(machine: Machine): Long

    @Update
    suspend fun updateMachine(machine: Machine)

    @Delete
    suspend fun deleteMachine(machine: Machine)

    @Query("SELECT * FROM notes WHERE clientId = :clientId ORDER BY createdAt DESC")
    fun notes(clientId: Long): Flow<List<Note>>

    @Insert
    suspend fun insertNote(note: Note)

    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE")
    fun allClients(): Flow<List<Client>>

    @Query("SELECT * FROM machines WHERE clientId = :clientId ORDER BY brand COLLATE NOCASE, model COLLATE NOCASE")
    fun allMachinesForClient(clientId: Long): Flow<List<Machine>>

    @Query("SELECT * FROM orders WHERE clientId = :clientId ORDER BY createdAt DESC")
    fun ordersForClient(clientId: Long): Flow<List<Order>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId ORDER BY id")
    fun orderItems(orderId: Long): Flow<List<OrderItem>>

    @Query("SELECT o.id, o.clientId, o.machineId, c.name AS clientName, m.brand AS machineBrand, m.model AS machineModel, o.status, o.comment, o.createdAt FROM orders o JOIN clients c ON c.id = o.clientId LEFT JOIN machines m ON m.id = o.machineId ORDER BY o.createdAt DESC")
    fun ordersWithDetails(): Flow<List<OrderWithDetails>>

    @Query("SELECT o.id, o.clientId, o.machineId, c.name AS clientName, m.brand AS machineBrand, m.model AS machineModel, o.status, o.comment, o.createdAt FROM orders o JOIN clients c ON c.id = o.clientId LEFT JOIN machines m ON m.id = o.machineId WHERE o.clientId = :clientId ORDER BY o.createdAt DESC")
    fun ordersWithDetailsForClient(clientId: Long): Flow<List<OrderWithDetails>>

    @Insert
    suspend fun insertOrder(order: Order): Long

    @Update
    suspend fun updateOrder(order: Order)

    @Delete
    suspend fun deleteOrder(order: Order)

    @Insert
    suspend fun insertOrderItem(item: OrderItem): Long

    @Update
    suspend fun updateOrderItem(item: OrderItem)

    @Delete
    suspend fun deleteOrderItem(item: OrderItem)

    @Insert
    suspend fun insertPayment(payment: Payment): Long

    @Delete
    suspend fun deletePayment(payment: Payment)

    @Query("""
        SELECT p.id, p.orderId, p.amount, p.paidAt, p.comment,
               COALESCE((SELECT SUM(oi.quantity * oi.price) FROM order_items oi WHERE oi.orderId = p.orderId), 0.0) AS orderTotal,
               o.status AS orderStatus
        FROM payments p
        JOIN orders o ON o.id = p.orderId
        WHERE o.clientId = :clientId
        ORDER BY p.paidAt DESC
    """)
    fun paymentsForClient(clientId: Long): Flow<List<PaymentWithOrder>>

    @Query("""
        SELECT o.id, o.machineId, o.status, o.createdAt,
               COALESCE((SELECT SUM(oi.quantity * oi.price) FROM order_items oi WHERE oi.orderId = o.id), 0.0) AS total,
               COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.orderId = o.id), 0.0) AS paid,
               COALESCE((SELECT SUM(oi.quantity * oi.price) FROM order_items oi WHERE oi.orderId = o.id), 0.0)
                 - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.orderId = o.id), 0.0) AS remaining
        FROM orders o
        WHERE o.clientId = :clientId
          AND (
              COALESCE((SELECT SUM(oi.quantity * oi.price) FROM order_items oi WHERE oi.orderId = o.id), 0.0)
              - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.orderId = o.id), 0.0)
          ) > 0.000001
        ORDER BY o.createdAt DESC
    """)
    fun unpaidOrdersForClient(clientId: Long): Flow<List<UnpaidOrder>>

    @Query("""
        SELECT COALESCE(
            SUM(
                COALESCE((SELECT SUM(oi.quantity * oi.price) FROM order_items oi WHERE oi.orderId = o.id), 0.0)
                - COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.orderId = o.id), 0.0)
            ), 0.0
        )
        FROM orders o
        WHERE o.clientId = :clientId
    """)
    fun clientDebt(clientId: Long): Flow<Double>

    @Query("SELECT * FROM tasks ORDER BY completed, dueAt")
    fun tasks(): Flow<List<Task>>

    @Insert
    suspend fun insertTask(task: Task)

    @Update
    suspend fun updateTask(task: Task)

    @Delete
    suspend fun deleteTask(task: Task)
}

@Database(
    entities = [Client::class, Note::class, Task::class, Machine::class, Order::class, OrderItem::class, Payment::class
        Supplier::class,
        SupplierPurchase::class,
        SupplierPayment::class,],
    version = 14,
    exportSchema = false
)
abstract class CrmDatabase : RoomDatabase() {
    abstract fun dao(): CrmDao

    companion object {
        @Volatile private var INSTANCE: CrmDatabase? = null

        fun get(context: android.content.Context): CrmDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CrmDatabase::class.java,
                    "crm.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }


    @Query("SELECT * FROM payments WHERE orderId = :orderId ORDER BY paidAt DESC")
    fun paymentsForOrder(orderId: Long): Flow<List<Payment>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE orderId = :orderId")
    fun paidAmount(orderId: Long): Flow<Double>

    @Query("SELECT COALESCE(SUM(p.amount), 0) FROM payments p INNER JOIN orders o ON p.orderId = o.id WHERE o.clientId = :clientId")
    fun clientPaidAmount(clientId: Long): Flow<Double>

    @Insert
    suspend fun insertPayment(payment: Payment): Long

    @Delete
    suspend fun deletePayment(payment: Payment)


    @Query("""
        SELECT method AS method, COALESCE(SUM(amount), 0) AS total
        FROM payments
        WHERE paidAt BETWEEN :fromDate AND :toDate
        GROUP BY method
        ORDER BY total DESC
    """)
    fun paymentMethodReport(fromDate: Long, toDate: Long): Flow<List<PaymentMethodTotal>>

    @Query("""
        SELECT COALESCE(SUM(amount), 0)
        FROM payments
        WHERE paidAt BETWEEN :fromDate AND :toDate
    """)
    fun paymentTotalReport(fromDate: Long, toDate: Long): Flow<Double>


    // ===== Suppliers =====
    @Query("""
        SELECT s.*,
               COALESCE((SELECT SUM(amount) FROM supplier_purchases WHERE supplierId = s.id), 0) AS totalPurchases,
               COALESCE((SELECT SUM(amount) FROM supplier_payments WHERE supplierId = s.id), 0) AS totalPaid
        FROM suppliers s
        ORDER BY s.name COLLATE NOCASE
    """)
    fun supplierBalances(): Flow<List<SupplierBalanceRow>>

    @Query("SELECT * FROM suppliers WHERE id = :id LIMIT 1")
    fun supplier(id: Long): Flow<Supplier?>

    @Insert
    suspend fun insertSupplier(supplier: Supplier): Long

    @Update
    suspend fun updateSupplier(supplier: Supplier)

    @Delete
    suspend fun deleteSupplier(supplier: Supplier)

    @Query("""
        SELECT * FROM supplier_purchases
        WHERE supplierId = :supplierId
        ORDER BY purchaseDate DESC, id DESC
    """)
    fun supplierPurchases(supplierId: Long): Flow<List<SupplierPurchase>>

    @Query("SELECT * FROM supplier_purchases WHERE id = :id LIMIT 1")
    fun supplierPurchase(id: Long): Flow<SupplierPurchase?>

    @Insert
    suspend fun insertSupplierPurchase(purchase: SupplierPurchase): Long

    @Update
    suspend fun updateSupplierPurchase(purchase: SupplierPurchase)

    @Delete
    suspend fun deleteSupplierPurchase(purchase: SupplierPurchase)

    @Query("""
        SELECT * FROM supplier_payments
        WHERE purchaseId = :purchaseId
        ORDER BY paidAt DESC, id DESC
    """)
    fun supplierPayments(purchaseId: Long): Flow<List<SupplierPayment>>

    @Query("""
        SELECT COALESCE(SUM(amount), 0)
        FROM supplier_payments
        WHERE purchaseId = :purchaseId
    """)
    fun supplierPurchasePaidAmount(purchaseId: Long): Flow<Double>

    @Insert
    suspend fun insertSupplierPayment(payment: SupplierPayment): Long

    @Query("DELETE FROM supplier_payments WHERE id = :id")
    suspend fun deleteSupplierPayment(id: Long)

    @Query("""
        SELECT COALESCE(SUM(p.amount), 0) - COALESCE(SUM(sp.amount), 0)
        FROM supplier_purchases p
        LEFT JOIN supplier_payments sp ON sp.purchaseId = p.id
        WHERE p.supplierId = :supplierId
    """)
    fun supplierDebt(supplierId: Long): Flow<Double>

}
