package com.example.simplecrm.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Order::class,
            parentColumns = ["id"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("orderId")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val paidAt: Long = System.currentTimeMillis(),
    val amount: Double,
    val method: String = "Наличные",
    val comment: String = ""
)

enum class PaymentStatus {
    UNPAID,
    PARTIALLY_PAID,
    PAID
}
